"""FastAPI application factory and lifespan."""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI
from fastapi.exceptions import HTTPException as FastAPIHTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.requests import Request
from fastapi.responses import JSONResponse

from momdiary.config import get_settings
from momdiary.db.engine import dispose_engine, get_session_factory
from momdiary.observability.logging import configure_logging, get_logger
from momdiary.observability.middleware import CorrelationIdMiddleware

logger = get_logger(__name__)


@asynccontextmanager
async def _lifespan(app: FastAPI) -> AsyncIterator[None]:
    configure_logging()
    settings = get_settings()
    logger.info("app.startup", title=app.title, version=app.version)

    sweeper_task: asyncio.Task[None] | None = None
    # Feature 009: start the chat-session TTL sweeper only when we're on
    # the Postgres backend. The in-memory store does its own lazy sweep
    # on every `get_or_create` and needs no background work.
    if settings.momdiary_session_store == "postgres":
        from momdiary.agents.session_sweeper import run_session_ttl_sweeper

        sweeper_task = asyncio.create_task(
            run_session_ttl_sweeper(
                get_session_factory(),
                ttl_seconds=settings.momdiary_session_ttl_seconds,
                interval_seconds=settings.momdiary_session_sweep_interval_seconds,
            ),
            name="chat-session-ttl-sweeper",
        )

    try:
        yield
    finally:
        logger.info("app.shutdown")
        if sweeper_task is not None:
            sweeper_task.cancel()
            try:
                await sweeper_task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
        await dispose_engine()


def create_app() -> FastAPI:
    """Application factory used by uvicorn and the contract tests."""
    app = FastAPI(
        title="MomDiary Baby Tracker Backend",
        version="0.1.0",
        lifespan=_lifespan,
    )
    settings = get_settings()
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.allowed_origins_list,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=[
            "Authorization",
            "Content-Type",
            "X-Active-Baby-Id",
            "X-Session-ID",
            "X-Correlation-ID",
        ],
        expose_headers=["X-Session-ID", "X-Correlation-ID"],
        allow_credentials=False,
    )
    from momdiary.auth.middleware import AuthLogContextMiddleware

    app.add_middleware(AuthLogContextMiddleware)
    app.add_middleware(CorrelationIdMiddleware)

    @app.exception_handler(FastAPIHTTPException)
    async def _envelope_http_exception_handler(
        request: Request, exc: FastAPIHTTPException
    ) -> JSONResponse:
        """Render `HTTPException(detail={"error":..., ...})` as a bare envelope."""
        if isinstance(exc.detail, dict) and "error" in exc.detail:
            return JSONResponse(status_code=exc.status_code, content=exc.detail)
        return JSONResponse(
            status_code=exc.status_code,
            content={"error": "http_error", "message": str(exc.detail)},
        )

    # Routers are registered lazily by their respective phases to keep this
    # module a stable composition root.
    from momdiary.api import (
        appointments,
        babies,
        entries,
        feeds,
        poops,
        research,
        sleeps,
        users,
        webhooks,
    )

    app.include_router(users.router, prefix="/v1")
    app.include_router(babies.router, prefix="/v1")
    app.include_router(entries.router, prefix="/v1")
    app.include_router(feeds.router, prefix="/v1")
    app.include_router(sleeps.router, prefix="/v1")
    app.include_router(poops.router, prefix="/v1")
    app.include_router(appointments.router, prefix="/v1")
    app.include_router(research.router, prefix="/v1")
    app.include_router(webhooks.router, prefix="/v1")
    logger.info("app.routers_registered", count=9)
    return app


app = create_app()
